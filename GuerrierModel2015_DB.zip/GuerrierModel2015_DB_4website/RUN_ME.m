clear; close all; clc;
% This is DBs recreation of the Guerrier 2015 Model see

% Guerrier, Claire, John A. Hayes, Gilles Fortin, and David Holcman. 
% ?Robust Network Oscillations during Mammalian Respiratory Rhythm 
% Generation Driven by Synaptic Dynamics.? Proceedings of the National 
% Academy of Sciences 112, no. 31 (August 4, 2015): 9728?33. 
% https://doi.org/10.1073/pnas.1421997112.


%% %%%%%%%%%%%% User Params %%%%%%%%%%%%%%%%

% Define the gridsize (x and y will be same length);
gridsize = 20; % gridsize 20 = 400 neurons :)

tmax = 2e4; % time to run in msec .don't make too large. 2e4 is good.

%%%%%%%%%%%% Do not touch %%%%%%%%%%%%%%
%%%%%%%%%%%% Below this line %%%%%%%%%%%
%% Make the network and connect it %%

MakeNetwork
GrowAxonsScript
MakeConnectivityMatrix


%% Simulate the network
tic

NetworkODE_v140

toc