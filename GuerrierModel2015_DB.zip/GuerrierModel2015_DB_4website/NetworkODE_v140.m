%NETWORKODE The entire network ode for model
%% Update History
%
% Version 1.4.0 - NeuronOfInterest. Adding neurons of interest to save
% their synaptic current isyn over course of simulation
%
% Version 1.3.8 - Evolutions Third. Going to try and replace as many
% heavisides as I can. Shaved 10 seconds off of a "2 second"
% simulation. 90sec --> 80sec
%
% Version 1.3.0 - Evolution 2. Trying to make a matrix of connections for
% CalcIsyn. So it doesn;nt need to sum(isyn(inputs)) in a loop
% Speed update, cut time from 157seconds to 90seconds in a "2 second"
% simulation
%
% Version 1.2.0 - Disinhibit. Making sure (ydock-ydock@AP) cannot be
% positive. This would lead to inhibition. It would also result because
% there was more vesciles in the synapse than there was during the AP. This
% would be because of the 1ms delay for ydock.
% Also going to update the figs a bit
%
% Version 1.1.0 - Second Evolutions. Changing the CalcISyn function to use
% N instead of finding the inputs everytime
%
% Version 1.0.0 - Clean Up. Model now runs (hopefully correctly). This
% update will focus on cleaning up the code and bug proofing it, as well as
% putting in some QoL fixes.
%
%
% Version 0.5.0 - Evolution. Archived the last version. Unclear if this
% model is equivilent to Guerrier model. Going to need to relook at
% conditional components of refractory period. Another important step is to
% speed up the integration. Therefore, update Evolution is about Speed.
% Largest memory hog is summing up spikes in NumAPrecord. Best way to fix
% this is to not save all APrecord, just the last 200ms worth.
%
% Version 0.4.2 - UrsaMinor. Reversed sign of synaptic connection. Made KI
% negative. I believe in their paper, they do (ydockt0-ydock) instead of
% the way the wrote it (ydock-ydockt0). So that's where there sign change
% happens. Mine will be on the KI parameter. 
% Unscheduled update - Revised refractory period conditions. Changed it to
% refractory period for synpatic output (rather than refractory for input)
% and also changed it from a refractory after firing to a refractory after
% bursting. Stole all the boolean conditional for what a "bursting event"
% is from the paper.
% This version does have bursting behavior!
% 
%
% Version 0.4.1 - Minor Update. Parameter changes
% increasing synaptic current strength (KI)
% 
% Version 0.4.0 - The Synapse Update
% Allow each neuron to calculate it's isyn at every time step
% Then receiving neurons (when not in refractory) grab the isyn for it's
% inputs.
%
% Version 0.3.0
% Implementing Runge-Kutta over Euler's
%
% Version 0.2.5 
% Going to take out synaptic component to make sure system can run without
% it
%
% Version 0.2
% Made the ode system using Euler integration, but simulation doesn't look
% right
%
% Version 0.1
% Tried to make ode function, probably unable to use ode45 for delayed ode

%% Parameters

% time parameters %%%%%%%%%%%%%%%
tmin = 0;
% tmax = 20e3; % moved to Run_Me script
tstep = 0.05;
t = tmin:tstep:tmax-tstep;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Initial conditions %%%%%%%%%%%%
%
%       [V   n   x yfree ydock]
yinit = [-65;.3;.33;.735;.15];
% x should be greater than .31
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Additional parameters %%%%%%%%%
global X; X = 0.3; %Equilibrium value of x
global T; T = -58; %Threshold voltage
ymaxdock = 0.18;
taudock = 738;
ymindock = 0.04;
xRefP = 0.31; % Threshold for refractory period

BufferTime = 500; % Time for cells to reach equilibrium before synapses turn on
tp = 200; % Window to look back for previous APs

KI = 2666; % Synaptic strength

sigma = 0.89; % Strength of noise

noi = [69;44;76];

%% Random pre-run stuff (Initializations)

% Assigning the ODEs numbers
numODEs = 5; %5 is the number of ODES
y1 = (1:numODEs:NumNeurons*numODEs)';
y2 = (2:numODEs:NumNeurons*numODEs)';
y3 = (3:numODEs:NumNeurons*numODEs)';
y4 = (4:numODEs:NumNeurons*numODEs)';
y5 = (5:numODEs:NumNeurons*numODEs)';

% slightly randomize intial conditions
yinit = repmat(yinit,NumNeurons,1);
yinit = yinit+(0.001*randn(NumNeurons*numODEs,1));


% Preparing the state matrix for the simulation
y = zeros(NumNeurons*numODEs,length(t));
y(:,1) = yinit;

% Create array to track APs
% 0s are no activity
% 1s are an AP
% Going to only allow tp/tstep amount of data
% ex: 200ms/0.05 = 4000 columns for each neuron.
% Trying to speed up code
APrecord = zeros(NumNeurons,tp/tstep);
% Keep full record for raster plot
FULLAPrecord = zeros(NumNeurons,length(t));

% Create array to track ydock value at an AP for a presynaptic neuron
ydockAPrecord = zeros(NumNeurons,1);

% Create array to track time since last AP. Set time to be -1000 for no
% confusion
TimeAPrecord = zeros(NumNeurons,1)-1000;

% Create array to track whether a cell is bursting or not
BoolBurst = false(NumNeurons,1);

% Create array to track whether a cell is in refaractory or not
BoolSilent = false(NumNeurons,1);

% Create Waitbar
H = waitbar(0,'Running Simulation','Position',[500 500 400 100]);
%H2 = figure('Position',[500 700 200 150]);

% Create Array to track simulation time
NUpdates4User = 20;
SimTimeArray = zeros(NUpdates4User+1,1);

% Create Array to svae neuron of interets key values (NeuronofInterest
% Update)
noiisyn = zeros(length(noi),length(t));

% Part of update Evolution 2. Prepare the connectivity matrix as matrix
% where each neuron is a row and the inputs to it are columns, avoid doing
% the Isyn(n)=sum(isyn(inputs) in a loop
% Ideally Isyn = sum(isyn(ppinputs),2,'omitnan')
ppinputs = zeros(NumNeurons)+NumNeurons+1;
for i = 1:NumNeurons
    inputs = N(i).InputsIdentifiers;
    ppinputs(i,1:length(inputs)) = inputs;
end
temp = sum(ppinputs);
temp2 = find(temp==(NumNeurons+1)*NumNeurons);
ppinputs(:,temp2(1):end) = [];
%Note, NumNeurons+1 is a better filler for the matrix than NaN because of
%summation problems in the CalcIsyn function

%%%%%%%%%%% Error Checking %%%%%%%%%%%%%%
if tp>BufferTime
    error('tp needs to be less than BufferTime')
end
if (length(t)/NUpdates4User-ceil(length(t)/NUpdates4User))
    error('Number of updates for user is not a factor of the total time steps')
end
% if any(yinit(y3) < xRefP)
%     error('synaptic facilitation shouldnt fall below (or start below) xRefP')
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Meat of Code %

% Begin simulation
for k = 1:length(t)-1

    
    % Calculate neuron's synaptic output if past buffer time (500ms)
    if t(k) < BufferTime
        isyn_array = zeros(NumNeurons,1);
    elseif t(k) >= BufferTime
        ydockdelay = y(y5,k-1/tstep);
        vdelay = y(y1,k-1/tstep); %%% CHECK BACK HERE, DO WE NEED VDELAY OR V??
        
        % Record how many spikes a neurons had in some amount of time, tp (200ms)
        %NumAPrecord = sum(APrecord(:,(k+1)-tp/tstep:k+1),2);
        NumAPrecord = sum(APrecord,2);
        
        [isyn_array,BoolBurst,BoolSilent] = CalciSyn(ydockdelay,ydockAPrecord,vdelay,T,ymindock,t(k),TimeAPrecord,BoolBurst,BoolSilent,NumAPrecord,y(y3,k),xRefP,KI);
        noiisyn(:,k) = isyn_array(noi);
    end
        Isyn_array = CalcIsyn(ppinputs,isyn_array);
        
    
    % Runge-Kutta Method
    RKV1 = tstep*( VODE(t(k),y(y1,k),y(y2,k),Isyn_array));
    RKn1 = tstep*( nODE(y(y1,k),y(y2,k))                                  );
    RKx1 = tstep*( xODE(y(y1,k),y(y3,k))                                  );      
    RKf1 = tstep*( yfreeODE(y(y1,k),y(y3,k),y(y4,k),y(y5,k),ymaxdock,taudock)              );
    RKd1 = tstep*( ydockODE(y(y1,k),y(y3,k),y(y4,k),y(y5,k),ymaxdock,taudock)              );

    RKV2 = tstep*( VODE(t(k)+(tstep/2),y(y1,k)+(RKV1/2),y(y2,k)+(RKn1/2),Isyn_array));
    RKn2 = tstep*( nODE(y(y1,k)+(RKV1/2),y(y2,k)+(RKn1/2))                                  );
    RKx2 = tstep*( xODE(y(y1,k)+(RKV1/2),y(y3,k)+(RKx1/2))                                  );      
    RKf2 = tstep*( yfreeODE(y(y1,k)+(RKV1/2),y(y3,k)+(RKx1/2),y(y4,k)+(RKf1/2),y(y5,k)+(RKd1/2),ymaxdock,taudock) );
    RKd2 = tstep*( ydockODE(y(y1,k)+(RKV1/2),y(y3,k)+(RKx1/2),y(y4,k)+(RKf1/2),y(y5,k)+(RKd1/2),ymaxdock,taudock) );
    
    RKV3 = tstep*( VODE(t(k)+(tstep/2),y(y1,k)+(RKV2/2),y(y2,k)+(RKn2/2),Isyn_array));
    RKn3 = tstep*( nODE(y(y1,k)+(RKV2/2),y(y2,k)+(RKn2/2))                                  );
    RKx3 = tstep*( xODE(y(y1,k)+(RKV2/2),y(y3,k)+(RKx2/2))                                  );      
    RKf3 = tstep*( yfreeODE(y(y1,k)+(RKV2/2),y(y3,k)+(RKx2/2),y(y4,k)+(RKf2/2),y(y5,k)+(RKd2/2),ymaxdock,taudock) );
    RKd3 = tstep*( ydockODE(y(y1,k)+(RKV2/2),y(y3,k)+(RKx2/2),y(y4,k)+(RKf2/2),y(y5,k)+(RKd2/2),ymaxdock,taudock) );
    
    RKV4 = tstep*( VODE(t(k)+(tstep),y(y1,k)+(RKV3),y(y2,k)+(RKn3),Isyn_array));
    RKn4 = tstep*( nODE(y(y1,k)+(RKV3),y(y2,k)+(RKn3))                                  );
    RKx4 = tstep*( xODE(y(y1,k)+(RKV3),y(y3,k)+(RKx3))                                  );      
    RKf4 = tstep*( yfreeODE(y(y1,k)+(RKV3),y(y3,k)+(RKx3),y(y4,k)+(RKf3),y(y5,k)+(RKd3),ymaxdock,taudock) );
    RKd4 = tstep*( ydockODE(y(y1,k)+(RKV3),y(y3,k)+(RKx3),y(y4,k)+(RKf3),y(y5,k)+(RKd3),ymaxdock,taudock) );
    
    y(y1,k+1) = y(y1,k) + (1/6) * (RKV1+2*RKV2+2*RKV3+RKV4) + noise(tstep,NumNeurons,sigma);
    y(y2,k+1) = y(y2,k) + (1/6) * (RKn1+2*RKn2+2*RKn3+RKn4);
    y(y3,k+1) = y(y3,k) + (1/6) * (RKx1+2*RKx2+2*RKx3+RKx4);
    y(y4,k+1) = y(y4,k) + (1/6) * (RKf1+2*RKf2+2*RKf3+RKf4);
    y(y5,k+1) = y(y5,k) + (1/6) * (RKd1+2*RKd2+2*RKd3+RKd4);
    
    % Record neurons that are spiking
    % Note where I put the AP here. I place it in the next time slot.
    % However, this also applies to where ydock @ t0 is. (y(y5,k+1))
    % still filling up window t<tp, then use mod to cycle back through,
    % always having a 200ms history, order of columns doesn't matter!
    % Brilliant!
    [tempAPrec,ydockAPrecord,TimeAPrecord] = APtracker(y(y1,k+1),y(y1,k),T,ydockAPrecord,y(y5,k+1),TimeAPrecord,t(k));
    APrecord(:,mod(k-1,tp/tstep)+1) = tempAPrec;
    FULLAPrecord(:,k+1) = tempAPrec;
        
    UpdateUser = length(t)/NUpdates4User;
    if mod(k,UpdateUser) == 0
        waitbar(k/length(t),H);
        SimTimeArray(k*NUpdates4User/length(t)+1) = toc;
    end
    

end
SimTimeArray(end) = toc; close(H);

%% figures %
set(0, 'DefaultAxesFontSize', 12)

% Simulation run time plot
figure('Position',[1800 200 600 200]); hold on; title('Simulation Time')
area(1:NUpdates4User,diff(SimTimeArray),'FaceColor',[0 .75 .75]); xlabel('Previous Segements of Simulation'); 
ylabel('Time (seconds)')
xlim([min(diff(SimTimeArray)) max(diff(SimTimeArray))])
set(gca,'FontSize',14);

% Voltage traces of a few neurons
figure('Position',[50 200 600 500]); hold on; 
title('Voltage traces of a few neurons (neighbors)')
plot(t,y(5*43+1,:),'r'); plot(t,y(5*44+1,:),'b'); plot(t,y(5*45+1,:),'g');
xlabel('Time (ms)');ylabel('Voltage (mV)');legend('cell 44','cell 45','cell 46')
set(gca,'FontSize',14)

% Voltage traces of another few neurons
figure('Position',[50 700 600 500]); hold on; title('Voltage traces of a few neurons (non neighbors)')
plot(t,y(5*46+1,:),'r'); plot(t,y(5*88+1,:),'b'); plot(t,y(5*33+1,:),'g');
xlabel('Time (ms)');ylabel('Voltage (mV)');legend('cell 47','cell 112','cell 370')
set(gca,'FontSize',14)

% Average Voltage trace
figure('Position',[600 200 600 500]); hold on; title('Average voltage trace')
plot(t,mean(y(y1,:)));
xlabel('Time (ms)');ylabel('Voltage (mV)');
set(gca,'FontSize',14)

% Individual Neuron Zoom 1
temp = 62;
figure('Position',[1200 200 600 500]); hold on; title(['A single neuron (neuron ' mat2str(temp) ')'])
ax1 = subplot(5,1,1); plot(t,y(temp*5+1,:)); title('Voltage (V)')
ax2 = subplot(5,1,2); plot(t,y(temp*5+2,:)); title('Potassium gate (n)')
ax3 = subplot(5,1,3); plot(t,y(temp*5+3,:)); title('Facilitation Variable (x)')
ax4 = subplot(5,1,4); plot(t,y(temp*5+4,:)); title('Free vesicles (yfree)')
ax5 = subplot(5,1,5); plot(t,y(temp*5+5,:)); title('Docked vesicles (ydock)')
xlabel('Time(ms)')
linkaxes([ax1,ax2,ax3,ax4,ax5],'x')
clear temp ax1 ax2 ax3 ax4 ax5

% Grouped Neuron Zoom 1
temp = 69;
Shift = 7;
figure('Position',[1200 700 600 500]); hold on; title(['A few neurons (non neighbors)' mat2str(temp-Shift) ',' ...
    mat2str(temp) ', and '  mat2str(temp+Shift) ])
ax1 = subplot(5,1,1); hold on
plot(t,y((temp-Shift)*5+1,:),'r');plot(t,y(temp*5+1,:),'b');plot(t,y((temp+Shift)*5+1,:),'g'); title('Voltage (V)')
ax2 = subplot(5,1,2); hold on
plot(t,y((temp-Shift)*5+2,:),'r');plot(t,y(temp*5+2,:),'b');plot(t,y((temp+Shift)*5+2,:),'g'); title('Potassium gate (n)')
ax3 = subplot(5,1,3); hold on
plot(t,y((temp-Shift)*5+3,:),'r');plot(t,y(temp*5+3,:),'b');plot(t,y((temp+Shift)*5+3,:),'g'); title('Facilitation Variable (x)')
ax4 = subplot(5,1,4); hold on
plot(t,y((temp-Shift)*5+4,:),'r');plot(t,y(temp*5+4,:),'b');plot(t,y((temp+Shift)*5+4,:),'g'); title('Free vesicles (yfree)')
ax5 = subplot(5,1,5); hold on
plot(t,y((temp-Shift)*5+5,:),'r');plot(t,y(temp*5+5,:),'b');plot(t,y((temp+Shift)*5+5,:),'g');title('Docked vesicles (ydock)')
linkaxes([ax1,ax2,ax3,ax4,ax5],'x')
xlabel('Time(ms)')
clear temp Shift ax1 ax2 ax3 ax4 ax5


myrasterplot(FULLAPrecord,tstep);
title('Raster Plot of Action Potentials')
set(gcf,'color','w');
set(gca,'FontSize',16);


% Neuron zoom on just a single burst (user will have to zoom on it)
figure; hold on;
title('Neuron zoom with isyn')
ax1 = subplot(4,1,1); hold on; plot(t,y((noi(1)-1)*5+1,:),'r'); ylabel('V_i')
ax2 = subplot(4,1,2); hold on; plot(t,y((noi(1)-1)*5+3,:),'g'); ylabel('x_i')
ax3 = subplot(4,1,3); hold on; plot(t,y((noi(1)-1)*5+5,:),'b'); ylabel('ydock_i')
ax4 = subplot(4,1,4); hold on; plot(t,noiisyn(1,:),'k'); ylabel('isyn_i')
linkaxes([ax1 ax2 ax3 ax4],'x')
xlabel('time (sec)');
clear ax1 ax2 ax3 ax4

% Params
figure('Position',[1800 450 600 200]); hold on;
sometext = {['KI = ' mat2str(KI)],...
            ['T = ' mat2str(T)],...
            ['taudock = ' mat2str(taudock)],... 
            ['tp = ' mat2str(tp)],...
            ['X = ' mat2str(X)],...
            ['xRefP = ' mat2str(xRefP)],...
            ['sigma = ' mat2str(sigma)],...
            's = 0.9'...
            };
%annotation('textbox',[0 0],'String',sometext)
text(0,0,sometext,'FontSize',15);
axis([-5 5 -5 5])

%% AP current functions
    
    function Iappout = Iapp(t,V)
        % Applied current
        %if t>6 && t<11
            Iappout = 0;
        %else
        %    Iappout = 0;
        %end
    end

    function INaout = INa(V,n)
        % Transient sodium current
        
        % maximum sodium conductance (mS.cm^-2)
        gNa = 120;
        % reversal for sodium
        ENa = 50;
        
        h = (0.89 - 1.1*n);
        
        INaout = gNa * minf(V).^3 .* h .* (V-ENa);
    end

    function IKout = IK(V,n)
        % DR Potassium
        
        % maximum potassium conductance
        gK = 36;
        %reversal for potassium
        EK = -77;
        
        IKout = gK*(n.^4).*(V-EK);
    end

    function ILout = IL(V)
        % Leakage
        
        gL = .3;
        EL = -54.4;
        
        ILout = gL*(V-EL);
    end

    function minfout = minf(V)
        % activation function for sodium
        minfout = alpham(V)./(alpham(V)+betam(V));
    end

    function alphamout = alpham(V)
        % Again, the alpha and beta provided in the paper did not work
        % So these functions come out of their code
        Refpot = -65;
        alphamout = (2.5-0.1*(V-Refpot))./(exp(2.5-0.1*(V-Refpot))-1);
    end
    
    function betamout = betam(V)
        Refpot = -65;
        betamout = 4*exp(-(V-Refpot)/18);
    end
    

    function noiseout = noise(deltat,NumNeurons,sigma)
    
        noiseout = sigma * sqrt(deltat) * randn(NumNeurons,1);
    end

%% Synaptic Functions

function [ur1,ur2,TimeAPrecord] = APtracker(newVs,oldVs,T,oldr2,ydock,oldTimeAPr,t)
    % This function takes the new voltages and old voltages and checks if
    % there was an AP, if there was, it assigns a 1 to the AP record.
    % Only one column is done here at a time to save memory
    % ur1 is updated APrecord
    % ur2 is the updated ydockAPrecord
    % TimeAPrecord is the time since a previous AP
    % Vs are the voltages
    % T is the threshold for an action potential
    % oldr2 is the vector for the old ydockAPrecord
    % ydock is the ydock at the new time
    % oldTimeAPr is the old TimeAPrecord
    % t is just the time
    ur1 = zeros(length(newVs),1);
    ur2 = oldr2;
    TimeAPrecord = oldTimeAPr;
    for n = 1:length(newVs)
        if newVs(n)>T && oldVs(n)<T
            ur1(n) = 1;
            ur2(n) = ydock(n);
            TimeAPrecord(n) = t;
        end
    end
end

function [isyn,BoolBurst,BoolSilent] = CalciSyn(ydockdelay,ydockAPrecord,V,T,ymindock,t,TimeAPrecord,BoolBurst,BoolSilent,NumAPrecord,x,xRefP,KI)
    % Function that calculates the synaptic output of each neuron. Most
    % will be 0 until a busting event
    
    % ydockdelay is the amount of vesicles in the synapse with a 1ms delay
    % ydockAPrecord is the amount of vesicles in the synapse when the AP
    % came
    % V is the voltage of the cell, also on a delay
    % T is the threshold for firing
    % ymindock is the minimal amount of vesicles for the synapse to have
    % before we set ydock to zero
    % t is the time
    % TimeAPrecord is the time of the previous AP
    % x is the faciliation variable
    % xRefP is the threshold for refractory period from a burst event
    % KI is the synapse strength

     % We need someway to determine wether or not we are in a refractory
     % period due to a bursting event. They don't go into details about the
     % bursting event in the paper but they do in their code. Here it
     % goes...
     
     % F == 0 if there are no spikes in last 50ms
     F = (t-TimeAPrecord) < 50;
     % G == 1 is there was a spike (F==1) AND there is no bursting (~Boolburst)
     G = F & ~BoolBurst;
     % We are bursting if number of spikes in last 200ms is > 10
     BoolBurst(G) = NumAPrecord(G) > 10;
     % Stop if we are bursting (Boolburst) and there was a spike in last 50 seconds (~F) 
     % OR
     % we are out of vesicles (ydockdelay<ymindock)
     Stop = (BoolBurst & ~F)|(ydockdelay<ymindock);
     % Be silent if we stop or if we are already silent and are in
     % refractory
     BoolSilent=Stop|(BoolSilent & x > xRefP);
     % Update BoolBurst
     BoolBurst(BoolSilent==1)=0;
    
     
     VesiclesOut = (ydockAPrecord-ydockdelay);
     VesiclesOut = VesiclesOut.*(VesiclesOut>=0);

     isyn = KI*(VesiclesOut).*(V>T).*(1-BoolSilent);
    
end

function Isyn = CalcIsyn(ppinputs,isyn_array)
    % Function to sum up the synaptic inputs for each cell and return a
    % NNx1 array of ISyn
    % C is connectivity matrix
    % isyn_array is the synaptic outputs of each neuron
    % x is facilitation varaible
    % xRefP is the threshold for refractory period from bursting
     %NumNeurons = length(isyn_array);
     %tempIsyn = zeros(NumNeurons,1);
     isyn_array(end+1) = 0;

     
     Isyn = sum(isyn_array(ppinputs),2);

     
end
       
%%  ODE functions %%%%%
function dVdt = VODE(t,V,n,Isyn_array)
    Cap = 1;
    %Isyn = CalcIsyn(C,Isyn_array,x,xRefP);
    dVdt = (Iapp(t,V) - INa(V,n) - IK(V,n) - IL(V) + Isyn_array) * (1/Cap);
end

function dndt = nODE(V,n)
    %dndt = (alpha(V,2).*(1-n)) - (beta(V,2).*n);
    % The paper's version of dndt did not run correctly. n was 1 for most
    % biological values of V
    Refpot = -65;
    dndt = 0.1*(1-0.1*(V-Refpot)).*(1-n)./(exp((1-0.1*(V-Refpot)))-1) - 0.125*exp(-(V-Refpot)/80).*n;
end

function dxdt = xODE(V,x)
    global X
    global T
    FP = 0.08;
    tauf = 700; %facilitation time constant
    dxdt = ((X-x)/tauf) + FP*(1-x) .* (V>T);
end

function dyfreedt = yfreeODE(V,x,yfree,ydock,ymaxdock,taudock)
    global T
    global X
    taurec = 3000;    
    dyfreedt = ((1-yfree-ydock)/taurec) - (1/taudock)*(ymaxdock-ydock).*yfree.*(1+(x-X)/X.*(V>T));
end

function dydockdt = ydockODE(V,x,yfree,ydock,ymaxdock,taudock)
    global T
    global X
    taurel = 47;

    dydockdt = (1/taudock)* (ymaxdock-ydock).*yfree.*(1+(x-X)/X.*(V>T)) - (1/taurel)*ydock.*((x-X)/X).*(V>T);
end
