% Make the network

% Determine the number of neurons from gridsize
NumNeurons = gridsize^2;

%%%%%%%%%
% 5 10 15
% 4 9  14
% 3 8  13
% 2 7  12
% 1 6  11 
%%%%%%%%%
i = 0;
for x = 1:gridsize
    for y = 1:gridsize
        i = i+1;
        N(i) = Neuron(x,y,i);
    end
end

clear i x y