% Function to create a raster plot
function myrasterplot(ActivityMatrix,dt)
% Activity Matrix is a matrix of 1s and 0s, where 1 is an event and
% 0 is not. The number of trials should equal to the number of rows, the
% number of samples should be equal to the number of columns
% dt is the sampling rate (1ms, 1 sec, .05ms)

[T,S] = size(ActivityMatrix);

tt = 0:dt:S*dt-dt;
yy = NaN(T,S);

for r=1:T
    yshift = T+1-r;
    for c = 1:S
        if ActivityMatrix(r,c) == 1 %maybe try ~=0 here for speed?
            yy(r,c) = yshift;
        end
    end
end

figure('Position',[600 700 600 500]); hold on;
title('Raster Plot')
set(gca,'FontSize',16)
plot(tt,yy,'kx');
xlabel('Time (ms)')
ylabel('Neuron number')


end