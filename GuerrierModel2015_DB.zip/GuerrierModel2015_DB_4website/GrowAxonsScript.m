% Run after network is made

Networkin = N;

for k = 1:NumNeurons
   Networkout = Networkin(k).GrowAxons(Networkin,gridsize);
   Networkin = Networkout;
end
clear k

N = Networkout;

clear Networkin Networkout