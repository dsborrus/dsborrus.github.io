function ViewNet(networkDB)
%VIEWNET Function to view connectivity of net
% Maybe do some anaylsis on it too

GS = sqrt(length(networkDB));

%% Plot the grid with nodes and connections

% fig = figure; hold on;
% axis([0 GS+1 0 GS+1])
% 
% plot(meshgrid(1:GS,1:GS),'ko','MarkerSize',250/GS,'MarkerfaceColor','k');
% 
% 
% for i = 1:length(networkDB)
%    num_temp = size([networkDB(i).Outputs],1);
%    xarray = [networkDB(i).Location(1)*ones(num_temp,1) [networkDB(i).Outputs(:,1)]];
%    yarray = [networkDB(i).Location(2)*ones(num_temp,1) [networkDB(i).Outputs(:,2)]];
%    plot(xarray,yarray,'Color',[1 0 i/length(networkDB)])
%    clear num_temp xarray yarray
% end

%% Statistics

% % Mean outputs
% a = 0;
% for i = 1:length(networkDB)
%     a = a + size(networkDB(i).Outputs,1);
% end
% outs = a/length(networkDB)
% 
% % Mean inputs
% a = 0;
% for i = 1:length(networkDB)
%     a = a + size(networkDB(i).Inputs,1);
% end
% ins = a/length(networkDB)
% clear i


end

