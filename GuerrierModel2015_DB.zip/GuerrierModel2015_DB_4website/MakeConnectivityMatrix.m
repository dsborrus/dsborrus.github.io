% Make the connectivity matrix

%       1   2   3   4   5   6
%	1   0   1   0   1
%   2   1   0
%   3   0   1   0
%   4               0
%   5                   0  
%   6                       0
global C
C = zeros(NumNeurons,NumNeurons);

for c = 1:NumNeurons %cycle through one column at a time (receiving neuron at a time)
    ReceivingNeuron = N(c);
    for r = 1:NumNeurons % now cycle through sending neurons
        SendingNeuron = N(r);  
        if r==c  % make sure they aren't the same (even though I think this is impossible already)
            %C(r,c) = 0;
        elseif sum( ReceivingNeuron.InputsIdentifiers == SendingNeuron.Identifier ) 
            % check if the receiving neurons input identifiers match the identifier of the sender
            C(r,c) = 1;
        else
            %C(r,c) = 0;
        end
    end
end
clear r c SendingNeuron ReceivingNeuron

% view net?
if 1
 imshow(C); xlabel('Output Neurons, 1 - 400'); ylabel('Input Neurons, 1-400');
 title('Connectivity Matrix of the Network')
end
