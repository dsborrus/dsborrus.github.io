classdef Neuron
    %NEURON Just a neuron
    %   hold information about location and connections
    
    properties
        Location % [x,y] location in grid
        Outputs  % [x,y; x,y; ...] location of neurons synapsing to
        Inputs   % [x,y; x,y; ...] location of neurons receiving input from
        Identifier % An integer representing the neuron's place in the Network vector
        InputsIdentifiers % A list of integers that coorespond to the neuron's input's identifiers
    end
    
    methods
        function obj = Neuron(xLoc,yLoc,Iden)
            %NEURON Construct an instance of this class
            %   User defines where the neuron is
            obj.Location = [xLoc,yLoc];
            obj.Identifier = Iden;
        end
        
        function Networkout = GrowAxons(Neuron,Network,gridsize)
            %GrowAxons Branch out and find neighbors with a probability
            %based on distance.
            %   Loop through all possible neurons, determine probability of
            %   connecting to them. Roll the die. grow axon if success,
            %   skip if failure.
            % Neuron is the particular neuron to simulate axon growth
            % Network is the entire neuron network
            % gridsize is the total gridsize of the network
            
            s = 0.9; % connectivity parameter. See paper.
            
            if gridsize^2 ~= numel(Network)
                error('Grid Size is not the same size as the network provided')
            end
            
            % loop through whole network
            for i = 1:gridsize^2
                if i ~= Neuron.Identifier % check the neuron is not meta
                    PossibleNeuron = Network(i);
                    % pull the neurons location
                    xdis = abs( PossibleNeuron.Location(1) - Neuron.Location(1) );
                    ydis = abs( PossibleNeuron.Location(2) - Neuron.Location(2) );
                    % calculate probability of synapse
                    d = sqrt(xdis^2+ydis^2);
                    P = exp(-d^2/(2*s^2));
                    rand_temp = rand;
                    if rand_temp < P
                        % connection! - connect to new neuron
                        num_temp = size(Neuron.Outputs,1)+1;
                        Neuron.Outputs(num_temp,:) = [PossibleNeuron.Location(1),PossibleNeuron.Location(2)];
                        % update the net
                        Network(Neuron.Identifier) = Neuron;
                        clear num_temp
                        % update the mate
                        num_temp = size(PossibleNeuron.Inputs,1)+1;
                        Network(i).Inputs(num_temp,:) = [Neuron.Location(1),Neuron.Location(2)];
                        num_temp = length(PossibleNeuron.InputsIdentifiers)+1;
                        Network(i).InputsIdentifiers(num_temp) = [Neuron.Identifier];
                        clear num_temp
                        % else - connection failed, move on
                    end
                end
            end
            
            % update the net
            Network(Neuron.Identifier) = Neuron;
            Networkout = Network;
            
        end
        
    end
end

